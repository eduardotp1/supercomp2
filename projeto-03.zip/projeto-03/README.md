# Projeto 3
### Eduardo Tirta

## Execução

Siga os comando abaixo para gerar os arquivos compiláveis: 
```
mkdir build
cd build
cmake ..
make 
```

Para rodar o programa, basta utilizar

```./[nome_do_executavel] < ../[nome_do_arquivo_de_entrada]```